import xbmcaddon

MainBase = 'http://164.132.106.213/data/home/home.txt'
addon = xbmcaddon.Addon('plugin.video.anonymous')